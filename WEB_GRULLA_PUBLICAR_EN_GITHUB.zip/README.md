# La Grulla Blanca — versión web modular (R2–R18)

Este repositorio es **solo la distribución pública jugable** de La Grulla Blanca. No contiene el repositorio de desarrollo ni su historial de trabajo.

**Jugar:** abrir la web de GitHub Pages de este repositorio. Los archivos del juego están en la raíz (`index.html`, `assets/`, `data/`, `rituals/`). No es necesario instalar Node.js ni ejecutar un servidor local para jugar en Pages.

## Publicación

En **Settings → Pages**, elegir **Deploy from a branch**, rama **main**, carpeta **/(root)**. GitHub Pages se encarga de servir esta compilación estática mediante HTTPS. El archivo `.nojekyll` evita modificar los recursos.

## Integridad y versión

- Versión experimental modular R2–R18, 30 de octubre de 2026.
- SHA-256 de `index.html`: `5f6ccf6b2d67c3c167e41671892c997c7a9e3bb78a518b8e89fcda0bfabeaa61`.
- SHA-256 de `MANIFIESTO_SHA256.json`: `e88a316e675e84ba6113300f8314e74ae4f113cfd79c50a300ffa1e6d4786e65`.
- El manifiesto verifica los 331 archivos compilados. `.gitattributes` impide que Git convierta los saltos de línea.

## Advertencias

- Versión experimental: no certifica todavía todo el Arco 1; WORLD sigue deshabilitado.
- Las partidas guardadas bajo otro origen web (por ejemplo, localhost) no se trasladan automáticamente. Usar la exportación/importación del propio juego cuando corresponda.
- Los archivos descargados por un navegador (incluidos sus módulos JS) son públicos. No publicar en este repositorio datos secretos o respaldos privados.
